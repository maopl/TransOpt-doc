FAQ
================================

This section addresses common questions and issues that users might encounter when using PrismBO.

How do I submit the error information to the maintainer?
--------------------------------------------------------
Click on the `Submit error` button on the bottom right corner of the dashboard page. Type in the error information and click on the `Submit` button, the error 
information will be sent to the maintainer.



How do I report a bug?
----------------------
1. Clone the repository:

   ::

     $ export NODE_OPTIONS=--openssl-legacy-provider

