.. _mhgp:

MHGP
====

MHGP comes from **Google Vizier- A Service for Black-Box Optimization**:cite:`GolovinSMKKS17`
