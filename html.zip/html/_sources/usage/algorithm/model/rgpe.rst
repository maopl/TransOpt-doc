.. _rgpe:

RGPE
====

RGPE comes from **Scalable Meta-Learning for Bayesian Optimization using Ranking-Weighted Gaussian Process Ensembles**:cite:`FeurerBE15`
