.. _deepkernel:

DeepKernel
==========

The deep kernel Gaussian process comes from **Few-shot Bayesian Optimization with Deep Kernel Surrogates**:cite:`Wang2021`
