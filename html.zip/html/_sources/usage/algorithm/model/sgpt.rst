.. _sgpt:

SGPT
====

SGPT comes from **Scalable Gaussian process-based transfer surrogates for hyperparameter optimization**:cite:`WistubaSS18`
