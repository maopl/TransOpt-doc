.. _transformer:

Transformer
=============

This model comes from **PFNs4BO- In-Context Learning for Bayesian Optimization**:cite:`MullerFHH23`
