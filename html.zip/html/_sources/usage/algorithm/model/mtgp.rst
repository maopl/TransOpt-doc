.. _mtgp:

MTGP
====

MTGP comes from **Multi-task Bayesian optimization**