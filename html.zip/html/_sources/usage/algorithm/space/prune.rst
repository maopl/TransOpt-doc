.. _prune:

Prune
=====
