.. _initialization:

Transfer Learning for Initialization Design
===========================================



.. toctree::
   :maxdepth: 1
   :caption: Transfer Learning for Initialization Design

   aLI
   mi-smbo
   