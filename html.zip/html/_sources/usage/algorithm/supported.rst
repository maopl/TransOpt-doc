.. _alg:

Supported Algorithms
====================

