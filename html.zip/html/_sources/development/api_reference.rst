API Reference
=============

This section provides a detailed reference for the PrismBO API, including descriptions of all available endpoints and methods.

.. automodule:: prismbo
   :members: